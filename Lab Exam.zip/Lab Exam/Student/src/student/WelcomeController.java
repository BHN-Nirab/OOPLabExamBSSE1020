package student;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;

public class WelcomeController implements Initializable {

    public static String currentStudent;
    @FXML
    AnchorPane rootPane;
    @FXML
    TextField registrationNumber;
    @FXML
    TextField password;
    @FXML
    Label error;

    public void setLogin(ActionEvent event)
    {
        String registrationNumber = this.registrationNumber.getText();
        String password = this.password.getText();

        try {
            Socket socket = new Socket(Main.IP, Main.PORT);

            String command = "login";
            String delimiter = "?";
            String sendingData = "" + delimiter + "" + delimiter + command + delimiter + registrationNumber + delimiter + password;

            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            objectOutputStream.writeObject(sendingData);

            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());

            String receivingData = (String) objectInputStream.readObject();
            String[] data = receivingData.split("\\?");

            objectInputStream.close();
            objectOutputStream.close();
            socket.close();



            if(data[3].equals("true"))
            {
                currentStudent = registrationNumber;
                Parent root = FXMLLoader.load(getClass().getResource("/student/Student.fxml"));
                Scene scene = new Scene(root);
                Stage currWindow = (Stage) rootPane.getScene().getWindow();
                currWindow.setScene(scene);
                currWindow.show();

            }
            else
                error.setText("Can't login! try again");


        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        error.setText("");
    }
}
