package server;


import student.StudentController;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServeClient extends Thread {

    private Socket client;

    private ServeClient()
    {

    }

    public ServeClient(Socket client)
    {
        this.client = client;
    }

    public void run()
    {
        try {
            ObjectInputStream objectInputStream = new ObjectInputStream(client.getInputStream());
            String receivingData = (String) objectInputStream.readObject();

            String[] data = receivingData.split("\\?");
            String command = data[2];

            if(command.equals("login"))
            {
                boolean isLogin = false;

                try{
                    String registrationNumber = data[3];
                    String password = data[4];

                    StudentController studentController = new StudentController();
                    isLogin = studentController.login(registrationNumber, password);


                }catch(Exception e)
                {
                    isLogin = false;
                }

                String delimiter = "?";
                String sendingData = "" + delimiter + "" + delimiter + command + delimiter + isLogin;

                ObjectOutputStream objectOutputStream = new ObjectOutputStream(client.getOutputStream());
                objectOutputStream.writeObject(sendingData);

                objectInputStream.close();
                objectOutputStream.close();
                client.close();

            }

            else if(command.equals("initializeCertificate"))
            {
                String registrationNumber = data[3];

                StudentController studentController = new StudentController();

                String result = studentController.getCertificate(registrationNumber);

                String delimiter = "?";
                String sendingData = "" + delimiter + "" + delimiter + command + delimiter + result;

                ObjectOutputStream objectOutputStream = new ObjectOutputStream(client.getOutputStream());
                objectOutputStream.writeObject(sendingData);

                objectInputStream.close();
                objectOutputStream.close();
                client.close();

            }



        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


}
