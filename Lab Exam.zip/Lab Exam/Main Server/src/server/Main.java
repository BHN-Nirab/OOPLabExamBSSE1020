package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {

    public static int PORT = 8484;

    public static void main(String[] args) {

        try {
            ServerSocket serverSocket = new ServerSocket(PORT);

            System.out.println("Server started");

            while(true)
            {
                System.out.println("Waiting for connection...");

                Socket client = serverSocket.accept();

                System.out.println("Connected with " + client.getRemoteSocketAddress());

                ServeClient serveClient = new ServeClient(client);
                serveClient.start();

            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
